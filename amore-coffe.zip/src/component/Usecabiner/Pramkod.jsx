import React from 'react'

function Pramkod() {
  return (
    <div>Pramkod</div>
  )
}

export default Pramkod