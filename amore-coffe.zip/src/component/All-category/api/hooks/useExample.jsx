const useExample = () => {
    // NOTE: CREATE HOOK THAT WILL HANDLE YOUR SERVICE 
    // NOTE: YOU WILL USE THIS HOOK IN COMPONENT TO CALL THE OR USE isLoading, isSuccess, isError values (this hook will return these values)
};

export default useExample;
